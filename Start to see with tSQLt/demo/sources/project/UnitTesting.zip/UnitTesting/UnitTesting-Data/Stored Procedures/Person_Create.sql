﻿

/*
Description:
Create a new person

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial procedure
*/
CREATE PROCEDURE [dbo].[Person_Create]
    @PersonID INT OUTPUT,
    @FirstName VARCHAR(50) = NULL,
    @LastName VARCHAR(50) = NULL,
    @Address VARCHAR(100) = NULL,
    @City VARCHAR(50) = NULL,
    @Zipcode VARCHAR(8) = NULL,
    @Country VARCHAR(50) = NULL,
    @Email VARCHAR(100) = NULL
AS
BEGIN


    -- Set session options to make sure transactions are aborted correctly 
    -- and the procedure doesn't return the count 
    SET XACT_ABORT, NOCOUNT ON;

    -- Check the parameters	  
    IF (@FirstName IS NULL)
    BEGIN
        ;
        THROW 50000, 'Invalid parameter: @FirstName cannot be NULL!', 1;
        RETURN;
    END;

    -- Declare variables  
    DECLARE @sqlcmd NVARCHAR(MAX);
    DECLARE @params NVARCHAR(MAX);



    -- Set the SQL command  
    SET @sqlcmd
        = N'
			INSERT INTO dbo.Person(FirstName,LastName,Address,City,Zipcode,Country,Email) VALUES (@FirstName, @LastName, @Address, @City, @Zipcode, @Country, @Email); 
			SELECT @PersonID = SCOPE_IDENTITY();
		';

    SET @params
        = N'  
			@PersonID INT OUTPUT,
			@FirstName VARCHAR(50),
			@LastName VARCHAR(50),
			@Address VARCHAR(100),
			@City VARCHAR(50),
			@Zipcode VARCHAR(8),
			@Country VARCHAR(50),
			@Email VARCHAR(100)
		';

    EXECUTE sp_executesql @stmnt = @sqlcmd,
                          @params = @params,
                          @FirstName = @FirstName,
                          @LastName = @LastName,
                          @Address = @Address,
                          @City = @City,
                          @Zipcode = @Zipcode,
                          @Country = @Country,
                          @Email = @Email,
                          @PersonID = @PersonID OUTPUT;

END;