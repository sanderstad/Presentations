﻿/*
Description:
Procedure to get all persons

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial procedure
*/
CREATE PROCEDURE [dbo].[Person_GetAll]
AS
BEGIN
    SET NOCOUNT ON;

    -- Execute the SQL command 
    SELECT PersonId,
           FirstName,
           LastName,
           Address,
           City,
           Zipcode,
           Country,
           Email
    FROM [dbo].[Person];

END;