﻿CREATE TABLE [dbo].[Person] (
    [PersonId]  INT           IDENTITY (1, 1) NOT NULL,
    [FirstName] VARCHAR (50)  NOT NULL,
    [LastName]  VARCHAR (50)  NOT NULL,
    [Address]   VARCHAR (100) NOT NULL,
    [City]      VARCHAR (50)  NOT NULL,
    [Zipcode]   VARCHAR (8)   NOT NULL,
    [Country]   VARCHAR (50)  NOT NULL,
    [Email]     VARCHAR (100) NOT NULL,
    CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED ([PersonId] ASC)
);

