﻿CREATE TABLE [dbo].[Customer] (
    [CustomerID]    INT IDENTITY (1, 1) NOT NULL,
    [PersonID]      INT NOT NULL,
    [AccountNumber] INT NOT NULL,
    CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED ([CustomerID] ASC),
    CONSTRAINT [FK_Customer_person] FOREIGN KEY ([PersonID]) REFERENCES [dbo].[Person] ([PersonId])
);

