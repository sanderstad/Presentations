﻿/*
Description:
Test if the table has the correct columns

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial procedure
*/
CREATE PROCEDURE [TestBasic].[test If table dbo.Person has the correct columns Expect success]
AS
BEGIN
    SET NOCOUNT ON;

    ----- ASSEMBLE -----------------------------------------------
    -- Create the tables
    CREATE TABLE #actual
    (
        [SchemaName] NVARCHAR(128) NOT NULL,
        [ColumnName] sysname NOT NULL,
        [DataType] sysname NOT NULL,
        [LengthSize] SMALLINT NOT NULL,
        [Precision] TINYINT NOT NULL
    );

    CREATE TABLE #expected
    (
        [SchemaName] NVARCHAR(128) NOT NULL,
        [ColumnName] sysname NOT NULL,
        [DataType] sysname NOT NULL,
        [LengthSize] SMALLINT NOT NULL,
        [Precision] TINYINT NOT NULL
    );

    INSERT INTO #expected
    (
        SchemaName,
        ColumnName,
        DataType,
        LengthSize,
        Precision
    )
    VALUES
    (   N'dbo',    -- SchemaName - nvarchar(128)
        'Address', -- ColumnName - sysname
        'varchar', -- DataType - sysname
        100,       -- LengthSize - smallint
        0          -- Precision - tinyint
        ),
    (   N'dbo',    -- SchemaName - nvarchar(128)
        'City',    -- ColumnName - sysname
        'varchar', -- DataType - sysname
        50,        -- LengthSize - smallint
        0          -- Precision - tinyint
    ),
    (   N'dbo',    -- SchemaName - nvarchar(128)
        'Country', -- ColumnName - sysname
        'varchar', -- DataType - sysname
        50,        -- LengthSize - smallint
        0          -- Precision - tinyint
    ),
    (   N'dbo',    -- SchemaName - nvarchar(128)
        'Email',   -- ColumnName - sysname
        'varchar', -- DataType - sysname
        100,       -- LengthSize - smallint
        0          -- Precision - tinyint
    ),
    (   N'dbo',      -- SchemaName - nvarchar(128)
        'FirstName', -- ColumnName - sysname
        'varchar',   -- DataType - sysname
        50,          -- LengthSize - smallint
        0            -- Precision - tinyint
    ),
    (   N'dbo',     -- SchemaName - nvarchar(128)
        'LastName', -- ColumnName - sysname
        'varchar',  -- DataType - sysname
        50,         -- LengthSize - smallint
        0           -- Precision - tinyint
    ),
    (   N'dbo',     -- SchemaName - nvarchar(128)
        'PersonId', -- ColumnName - sysname
        'int',      -- DataType - sysname
        4,          -- LengthSize - smallint
        10          -- Precision - tinyint
    ),
    (   N'dbo',    -- SchemaName - nvarchar(128)
        'Zipcode', -- ColumnName - sysname
        'varchar', -- DataType - sysname
        8,         -- LengthSize - smallint
        0          -- Precision - tinyint
    );

    ----- ACT ----------------------------------------------------

    INSERT INTO #actual
    (
        SchemaName,
        ColumnName,
        DataType,
        LengthSize,
        Precision
    )
    SELECT OBJECT_SCHEMA_NAME(c.object_id) SchemaName,
           c.name AS ColumnName,
           st.name AS DataType,
           c.max_length AS LengthSize,
           c.precision AS [Precision]
    FROM sys.columns AS c
        INNER JOIN sys.tables AS t
            ON t.object_id = c.object_id
        LEFT JOIN sys.types AS st
            ON st.user_type_id = c.user_type_id
    WHERE t.type = 'U'
          AND t.name = 'Person'
    ORDER BY t.name,
             c.name;


    ----- ASSERT -------------------------------------------------

    -- Assert to have th same table
    EXEC tSQLt.AssertEqualsTable @Expected = '#expected', @Actual = '#actual';


END;