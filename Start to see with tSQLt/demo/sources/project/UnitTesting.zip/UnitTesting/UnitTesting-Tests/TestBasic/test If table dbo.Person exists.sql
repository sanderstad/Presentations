﻿/*
Description:
Test if the table dbo.Person exists

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial test
*/
CREATE PROCEDURE [TestBasic].[test If table dbo.Person exists]
AS
BEGIN
    SET NOCOUNT ON;

    ----- ASSERT -------------------------------------------------
    EXEC tSQLt.AssertObjectExists @ObjectName = N'dbo.Person';

END;