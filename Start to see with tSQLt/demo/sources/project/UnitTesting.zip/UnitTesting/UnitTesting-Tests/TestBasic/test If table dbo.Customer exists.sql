﻿/*
Description:
Test if the table dbo.Customer exists

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial test
*/
CREATE PROCEDURE [TestBasic].[test If table dbo.Customer exists]
AS
BEGIN
    SET NOCOUNT ON;

    ----- ASSERT -------------------------------------------------
    EXEC tSQLt.AssertObjectExists @ObjectName = N'dbo.Customer'; -- This will fail because the table Customers does not exist

END;
GO