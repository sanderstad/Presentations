﻿CREATE TYPE [tSQLt].[Private]
     EXTERNAL NAME [tSQLtCLR].[tSQLtCLR.tSQLtPrivate];

