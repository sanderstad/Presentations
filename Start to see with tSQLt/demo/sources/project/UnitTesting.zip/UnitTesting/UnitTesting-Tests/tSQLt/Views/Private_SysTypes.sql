﻿CREATE VIEW tSQLt.Private_SysTypes AS SELECT * FROM sys.types AS T;
