﻿CREATE TABLE [tSQLt].[Private_Configurations] (
    [Name]  NVARCHAR (100) NOT NULL,
    [Value] SQL_VARIANT    NULL,
    PRIMARY KEY CLUSTERED ([Name] ASC)
);

