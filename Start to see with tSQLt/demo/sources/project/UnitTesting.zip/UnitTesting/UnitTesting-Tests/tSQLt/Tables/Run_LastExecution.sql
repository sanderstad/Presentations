﻿CREATE TABLE [tSQLt].[Run_LastExecution] (
    [TestName]  NVARCHAR (MAX) NULL,
    [SessionId] INT            NULL,
    [LoginTime] DATETIME       NULL
);

