﻿CREATE TYPE [tSQLt].[AssertStringTable] AS TABLE (
    [value] NVARCHAR (MAX) NULL);

