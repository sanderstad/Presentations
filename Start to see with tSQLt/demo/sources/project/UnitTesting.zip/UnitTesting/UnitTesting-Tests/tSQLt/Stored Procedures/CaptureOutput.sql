﻿CREATE PROCEDURE [tSQLt].[CaptureOutput]
@command NVARCHAR (MAX) NULL
AS EXTERNAL NAME [tSQLtCLR].[tSQLtCLR.StoredProcedures].[CaptureOutput]

