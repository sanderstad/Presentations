﻿/*
Description:
Test the procedure Person_Create

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial procedure
*/
CREATE PROCEDURE [TestUnitTesting].[test Person - Create person Expect success]
AS
BEGIN
    SET NOCOUNT ON;

    ----- ASSEMBLE -----------------------------------------------

    -- Declare the variables
    DECLARE @actual INT,
            @expected INT;

    EXEC tSQLt.FakeTable @TableName = N'[dbo].[Person]',
                         @Identity = 1,
                         @ComputedColumns = 1,
                         @Defaults = 1;

    -- Get the expected value
    SELECT @expected = IDENT_CURRENT('dbo.Person');


    ----- ACT ----------------------------------------------------

    -- Execute the procedure
    EXEC dbo.Person_Create @PersonID = @actual OUTPUT, -- int
                           @FirstName = 'John',          -- varchar(50)
                           @LastName = 'Doe',            -- varchar(50)
                           @Address = 'Main street 7',   -- varchar(100)
                           @City = 'Whatever',           -- varchar(50)
                           @Zipcode = '12345',           -- varchar(8)
                           @Country = 'Republic of Me',  -- varchar(50)
                           @Email = 'test@test1.com';    -- varchar(100)

    ----- ASSERT -------------------------------------------------

    EXEC tSQLt.AssertEquals @expected, @actual;

END;
