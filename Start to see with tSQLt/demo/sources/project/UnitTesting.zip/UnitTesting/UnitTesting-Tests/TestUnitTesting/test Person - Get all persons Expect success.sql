﻿/*
Description:
Test the procedure Person_GetAll

Changes:
Date		Who						Notes
----------	---						--------------------------------------------------------------
10/08/2019	Sander Stad				Initial procedure
*/
CREATE PROCEDURE [TestUnitTesting].[test Person - Get all persons Expect success]
AS
BEGIN
    SET NOCOUNT ON;

    ----- ASSEMBLE -----------------------------------------------

    -- Create the fake table
    EXEC tSQLt.FakeTable @TableName = N'[dbo].[Person]',
                         @Identity = 1,
                         @ComputedColumns = 1,
                         @Defaults = 1;

    -- Insert dummy records into table
    INSERT INTO dbo.Person
    (
        FirstName,
        LastName,
        Address,
        City,
        Zipcode,
        Country,
        Email
    )
    VALUES
    (   'Eric',         -- FirstName - varchar(50)
        'Smith',        -- LastName - varchar(50)
        'Whatever 1',   -- Address - varchar(100)
        'Sweet Lake',   -- City - varchar(50)
        '12345',        -- Zipcode - varchar(8)
        'Germany',      -- Country - varchar(50)
        'esmith@cy.com' -- Email - varchar(100)
        ),
    (   'John',       -- FirstName - varchar(50)
        'Doe',        -- LastName - varchar(50)
        'Whatever 2', -- Address - varchar(100)
        'Sweet Lake', -- City - varchar(50)
        '12345',      -- Zipcode - varchar(8)
        'Germany',    -- Country - varchar(50)
        'jdoe@cy.com' -- Email - varchar(100)
    ),
    (   'Walter',         -- FirstName - varchar(50)
        'Jenkins',        -- LastName - varchar(50)
        'Whatever 3',     -- Address - varchar(100)
        'Sweet Lake',     -- City - varchar(50)
        '12345',          -- Zipcode - varchar(8)
        'Germany',        -- Country - varchar(50)
        'wjenkins@cy.com' -- Email - varchar(100)
    ),
    (   'Janet',          -- FirstName - varchar(50)
        'Sleepy',         -- LastName - varchar(50)
        'Whatever 4',     -- Address - varchar(100)
        'Sweet Lake',     -- City - varchar(50)
        '12345',          -- Zipcode - varchar(8)
        'Germany',        -- Country - varchar(50)
        'jsleeper@cy.com' -- Email - varchar(100)
    );


    -- Create the tables
    CREATE TABLE #actual
    (
        [PersonId] [INT] NOT NULL,
        [FirstName] [VARCHAR](50) NOT NULL,
        [LastName] [VARCHAR](50) NOT NULL,
        [Address] [VARCHAR](100) NOT NULL,
        [City] [VARCHAR](50) NOT NULL,
        [Zipcode] [VARCHAR](8) NOT NULL,
        [Country] [VARCHAR](50) NOT NULL,
        [Email] [VARCHAR](100) NOT NULL,
    );



    -- Get the expected rows
    SELECT PersonId,
           FirstName,
           LastName,
           Address,
           City,
           Zipcode,
           Country,
           Email
    INTO #expected
    FROM dbo.Person;


    ----- ACT ----------------------------------------------------

    -- Execute the procedure
    INSERT INTO #actual
    (
        PersonId,
        FirstName,
        LastName,
        Address,
        City,
        Zipcode,
        Country,
        Email
    )
    EXEC dbo.Person_GetAll;


    ----- ASSERT -------------------------------------------------

	-- Assert to have th same table
    EXEC tSQLt.AssertEqualsTable @Expected = '#expected', @Actual = '#actual';


END;